
// $('#para').hide()
// $('#about-btn').click(function () {
//   $('#para').slideToggle();
//   if ($('#about-btn').text() == "Read more") {
//     $(this).text("Read less")
//   } else {
//     $(this).text("Read more")
//   }
// });


// const navIcon = document.querySelector(".nav-icon");
// const nav = document.querySelector("nav");

// navIcon.onclick = function () {
//   nav.classList.toggle("show");
// };

// var navbar = document.querySelector("nav");

// window.onscroll = function () {
//   // pageYOffset or scrollY
//   if (window.pageYOffset > 70) {
//     navbar.classList.add("scrolled");


//   } else {
//     navbar.classList.remove("scrolled");
//     //$('nav').hide();
//   }
// };


// function mode() {
//   var x = document.getElementById("sun");
//   if (x.alt === "sun") {
//     x.alt = "moon";
//     x.src = "./bgs/moon.png";
//     document.body.style.background = "white";
//     document.body.style.color = "black";
//     document.querySelector(".nav-links").style.background = "white";
//     document.querySelector("nav").style.background = "white";
//     const navDiv = document.querySelector(".nav-content");
//     const matches = navDiv.querySelectorAll("a");
//     const html = document.querySelector("html").style.background = "white";
//     matches.forEach((a) => {
//       a.style.color = "black";
//     });
//     var x = document.querySelectorAll(".card_title, .card_text");
//     var i;
//     for (i = 0; i < x.length; i++) {
//       x[i].style.color = "black";
//     }
//     var y = document.querySelectorAll(".btn");
//     var j;
//     for (j = 0; j < y.length; j++) {
//       y[j].style.color = "black";
//       y[j].style.border = "1px solid rgb(0 0 0 / 20%)";
//     }
//     var z = document.querySelectorAll("#svg");
//     var k;
//     for (k = 0; k < z.length; k++) {
//       z[k].setAttribute("stroke", "black");
//     }
//     document.getElementById("x_svg"). style.fill= "black";

//     var a = document.querySelectorAll(".bar");
//     var r;

//     for (r = 0; r < a.length; r++) {
//       a[r].style.background = "#FD9346";
//     }
   

//     var n = document.querySelectorAll(".modal-header, .modal-body, .close,.modal-footer, .model-content");
//     for (i = 0; i < n.length; i++) {
//       n[i].style.color = "black";
//       n[i].style.background = "white";
//     }

//     document.querySelector("#svg-wp").setAttribute("fill", "black");

//   } else {
//     x.alt = "sun";
//     x.src = "./bgs/sun.png";
//     document.body.style.background = "black";
//     document.body.style.color = "white";
//     document.querySelector(".nav-links").style.background = "black";
//     document.querySelector("nav").style.background = "black";
//     const navDiv = document.querySelector(".nav-content");
//     const matches = navDiv.querySelectorAll("a");
//     const html = document.querySelector("html").style.background = "black";
//     matches.forEach((a) => {
//       a.style.color = "white";
//     });

//     var x = document.querySelectorAll(".card_title, .card_text");
//     var i;
//     for (i = 0; i < x.length; i++) {
//       x[i].style.color = "white";
//     }

//     var y = document.querySelectorAll(".btn");
//     var j;
//     for (j = 0; j < y.length; j++) {
//       y[j].style.color = "white";
//       y[j].style.border = "1px solid rgba(255, 255, 255, 0.2)";
//     }

//     var z = document.querySelectorAll("#svg");
//     var k;
//     for (k = 0; k < z.length; k++) {
//       z[k].setAttribute("stroke", "white");
//     }

//     var a = document.querySelectorAll(".bar");
//     var r;
//     for (r = 0; r < a.length; r++) {
//       a[r].style.background = "white";
//     }


//     var n = document.querySelectorAll(".modal-header, .modal-body, .close, .modal-footer,.model-content");
//     for (i = 0; i < n.length; i++) {
//       n[i].style.color = "white";
//       n[i].style.background = "#474a47";
//     }
//     document.getElementById("x_svg"). style.fill= "white";
//     document.querySelector("#svg-wp").setAttribute("fill", "white");
//   }
// }



// $(document).ready(function () {
  
//   $(".model-btn").click(function (event) {

//     var thisModel = $(this).data('target');
//     // var id = $(this).data('id');
//     // console.log(id);
  
  
//     // if (id == "personalLoan") {
//     //   $('.model-content h1').text("Personal Loan");
//     //   $(".modal-body p").text(personalLoan);
//     // } else {
  
//     // }
//     $(thisModel).show();
  
  
//     $(thisModel).find('[data-close="model"]').click(function () {
//       $(thisModel).hide();
//     });
//     $(window).click(function (event) {
//       if ('#' + event.target.id == thisModel) {
//         $(thisModel).hide();
//       }
//     });


//     var id = $(this).data('id');
//     console.log(id);


//     $.getJSON('loan.json', function (loans) {
//       if (id == "personalLoan") {
//         $('.model-content h1').text("Personal Loan");
       
//         $('#display').html('<p>' + loans.personalLoan + '</p>');
//       } 
      
//       else if(id == "carLoan"){
//         $('.model-content h1').text("Car Loan");
//         $('#display').html('<p>' + loans.carLoan + '</p>');
    
//       }
//       else if(id == "homeLoan"){
//         $('.model-content h1').text("Home Loan");
//         $('#display').html('<p>' + loans.homeLoan + '</p>');
    
//       }
//       else if(id == "educationLoan"){
//         $('.model-content h1').text("Education Loan");
//         $('#display').html('<p>' + loans.educationLoan + '</p>');
    
//       }
//       else if(id == "goldLoan"){
//         $('.model-content h1').text("Gold Loan");
//         $('#display').html('<p>' + loans.goldLoan + '</p>');
    
//       }
//       else if(id == "businessLoan"){
//         $('.model-content h1').text("Business Loan");
//         $('#display').html('<p>' + loans.businessLoan + '</p>');
    
//       }
//       else if(id == "twoWheelerLoan"){
//         $('.model-content h1').text("Two Wheeler Loan");
//         $('#display').html('<p>' + loans.twoWheelerLoan + '</p>');
    
//       }
//       else if(id == "holidayLoan"){
//         $('.model-content h1').text("Holiday Loan");
//         $('#display').html('<p>' + loans.holidayLoan + '</p>');
    
//       }
//       else if(id == "loanAgainstProperty"){
//         $('.model-content h1').text("Loan Against Property");
//         $('#display').html('<p>' + loans.loanAgainstProperty + '</p>');
    
//       }
//       else {
//         $('.model-content h1').text("Something went wrong");
//         $(".modal-body p").text("Go to home page");
//       }
      
//     });
//   });
// });