import logo from './logo.svg';
import './App.css';

import '../src/css/style.css'
import '../src/js/index'
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import SkillContent from './components/SkillContent';
import LoanTypes from './components/Project';
import Contact from './components/contact';
import MyModel from './components/mymodel';
import Footer from './components/Footer';



function App() {
  return (
    <>
      <Navbar />
      <div className='content'>
        <Hero />
        <About />
        <div className='skill' id='skills'>
          <div className="skill-head">
            <h1 className="skill-head-text">Why to choose Billionaire Fund?</h1>
          </div>
          <SkillContent />
          <LoanTypes />
          <Contact />
          <MyModel />
          <Footer/>
        </div>
      </div>
    </>
  );
}

export default App;
