import React from 'react';

const Footer = () => {
  return (
    <footer style={{ marginTop: '50px', marginBottom: '50px', textAlign: 'center' }}>
      Made with ❤️ by Rahul
    </footer>
  );
};

export default Footer;
