import React from 'react'

const Hero = () => {
  return (
    <div className="hero">
      <div className="greet gradient yellow">
        <h1 className="greet-text">Billionaire Fund</h1>
      </div>

      <div className="intro">
        <h2 className="intro-text typewriter"> Welcome to Billionaire Fund</h2>
        <h2 className="intro-text">
          <span
            className="gradient orange aos-init"
            style={{ marginRight: '15px' }}
            data-aos="fade-left"
            data-aos-duration="1000"
          >
            Live your dreams now
          </span>
          <span
            className="gradient pink aos-init"
            style={{ marginRight: '13px' }}
            data-aos="fade-left"
            data-aos-duration="1000"
          >
            Presenting a wide range of loans to power your dreams
          </span>
        </h2>
      </div>

      <a href="https://wa.me/+918999653939" target="_blank" rel="noopener noreferrer">
        <button
          className="btn card_btn"
          id="resume-btn"
          style={{
            textTransform: 'initial',
            width: 'fit-content',
            letterSpacing: '5px',
            padding: '14px 26px',
            fontSize: '16px',
          }}
        >
          Apply Now
        </button>
      </a>
    </div>
  )
}

export default Hero