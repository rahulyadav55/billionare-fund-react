import React from 'react';
import loansData from '../loan.json'; // Import your JSON file

const MyModel = ({ loanType, onClose, isVisible }) => {
  const selectedLoan = loanType || 'defaultLoanType';
  const loanData = loansData[selectedLoan] || { heading: 'Loading...', para: 'Loading...' };
  console.log(loanData.heading)
  console.log(loanData.para)
  

  return (
    <div id="mymodel" className={`model ${isVisible ? 'visible' : ''}`}>
      <div className="model-content">
        <div className="modal-header">
          <span className="close" onClick={onClose} data-close="model">×</span>
          <div className="greet gradient yellow">
            <h1>{loanData.heading}</h1>
          </div>
        </div>
        <div className="modal-body">
          <p id="display">
            <p>{loanData.para}</p>
          </p>
        </div>
        <div className="modal-footer">
          <a href="https://wa.me/+918999653939" target="_blank" rel="noopener noreferrer">
            <button className="btn card_btn" id="resume-btn" style={{ textTransform: 'initial', width: 'fit-content', letterSpacing: '5px', padding: '14px 26px', fontSize: '16px' }}>Apply Now</button>
          </a>
        </div>
      </div>
    </div>
  );
};

export default MyModel;
