import React, { useEffect, useState } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css'; // Make sure to include the AOS styles
import MyModel from './mymodel';

const LoanTypes = () => {
    useEffect(() => {
        AOS.init(); // Initialize AOS library for animations
    }, []);
    const [selectedLoan, setSelectedLoan] = useState(null);

    const openLoanModal = (loanType) => {

        setSelectedLoan(loanType);
    };

    const closeLoanModal = () => {
        setSelectedLoan(null);
    };
    return (
        <div className="project" id="works">
            <div className="project-head">
                <h1 className="project-head-text">Types of loan....</h1>
            </div>
            <div className="project-content">
                <ul className="cards">
                    {/* Personal Loan */}
                    <li className="cards_item" data-aos="zoom-in-up">
                        <div className="aos-init aos-animate">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/personal.png')} alt="Personal Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Personal Loan</h2>
                                    <p className="card_text">Personal loans are designed around your capital.....</p>

                                    <button id="personalLoan" className="btn model-btn card_btn" onClick={(e) => openLoanModal('personalLoan',e.currentTarget.getAttribute("data-card-title"))} data-card-title="Personal Loan" data-target="#mymodel" value={"Personal Loan"} data-id="personalLoan">
                                        Explore
                                    </button>
                                </div>
                            </div>
                        </div>
                    </li>
                    {/* Car Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init aos-animate">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/car.png')} alt="Car Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Car Loan</h2>
                                    <p className="card_text">Dreaming of owning a car? Billionaire Fund Car Loan aims.....</p>
                                    <button id="carLoan" data-id="carLoan" data-target="#mymodel"  onClick={() => openLoanModal('carLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>


                    {/* Home EMIs Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/home.png')} alt="Home EMIs Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Home EMIs Loan</h2>
                                    <p className="card_text">Our affordable and flexible home EMIs loan are designed.....</p>
                                    <button id="homeLoan" data-id="homeLoan" data-target="#mymodel" onClick={() => openLoanModal('homeLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Education Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/education.png')} alt="Education Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Education Loan</h2>
                                    <p className="card_text">Billionaire Fund brings you Education Loans for studies both in India.....</p>
                                    <button id="educationLoan" data-id="educationLoan" data-target="#mymodel" onClick={() => openLoanModal('educationLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Gold Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/gold.png')} alt="Gold Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Gold Loan</h2>
                                    <p className="card_text">Have an urgent need for cash, Now you can use your gold.....</p>
                                    <button id="goldLoan" data-id="goldLoan" data-target="#mymodel" onClick={() => openLoanModal('goldLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Business Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/business.png')} alt="Business Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Business Loan</h2>
                                    <p className="card_text">Are you a manufacturer, retailer, trader or a professional running.....</p>
                                    <button id="businessLoan" data-id="businessLoan" data-target="#mymodel" onClick={() => openLoanModal('businessLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Two Wheeler Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/bike.png')} alt="Two Wheeler Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Two Wheeler Loan</h2>
                                    <p className="card_text">Bringing home the ride of your choice has become easier.....</p>
                                    <button id="twoWheelerLoan" data-id="twoWheelerLoan" data-target="#mymodel" onClick={() => openLoanModal('twoWheelerLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Holiday Loan */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/holiday.png')} alt="Holiday Loan" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Holiday Loan</h2>
                                    <p className="card_text">If you’ve been dreaming of a vacation for a long time.....</p>
                                    <button id="holidayLoan" data-id="holidayLoan" data-target="#mymodel" onClick={() => openLoanModal('holidayLoan')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                    {/* Loan Against Property */}
                    <li className="cards_item">
                        <div data-aos="zoom-in-up" className="aos-init">
                            <div className="card">
                                <div className="card_image"><img src={require('../gifs/property.png')} alt="Loan Against Property" /></div>
                                <div className="card_content">
                                    <h2 className="card_title">Loan Against Property</h2>
                                    <p className="card_text">If you’re looking for funding and have a commercial.....</p>
                                    <button id="loanAgainstProperty" data-id="loanAgainstProperty" data-target="#mymodel" onClick={() => openLoanModal('loanAgainstProperty')} className="btn model-btn card_btn">Explore</button>
                                </div>
                            </div>
                        </div>
                    </li>

                   

                </ul>
            </div>
            <MyModel loanType={selectedLoan} onClose={closeLoanModal} isVisible={selectedLoan !== null} />
        </div>
    );
};

export default LoanTypes;
