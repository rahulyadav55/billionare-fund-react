import React, { useState, useEffect } from 'react';

const Navbar = () => {

  const [isDarkMode, setIsDarkMode] = useState(true);



  const toggleMode = () => {
    setIsDarkMode(!isDarkMode);
    applyTheme(!isDarkMode);
  };

  const applyTheme = (isDarkMode) => {
    const body = document.body;
    const navLinks = document.querySelector(".nav-links");
    const nav = document.querySelector("nav");
    const navDiv = document.querySelector(".nav-content");
    const matches = navDiv.querySelectorAll("a");
    const cardElements = document.querySelectorAll(".card_title, .card_text");
    const btnElements = document.querySelectorAll(".btn");
    const svgElements = document.querySelectorAll("#svg");
    const barElements = document.querySelectorAll(".bar");
    const modalElements = document.querySelectorAll(".modal-header, .modal-body, .close, .modal-footer, .model-content");
    const html = document.querySelector("html");
    const xSvg = document.getElementById("x_svg");
    const svgWp = document.querySelector("#svg-wp");

    if (isDarkMode) {
      body.style.background = "black";
      body.style.color = "white";
      navLinks.style.background = "black";
      nav.style.background = "black";
      html.style.background = "black";

      matches.forEach((a) => {
        a.style.color = "white";
      });

      cardElements.forEach((el) => {
        el.style.color = "white";
      });

      btnElements.forEach((btn) => {
        btn.style.color = "white";
        btn.style.border = "1px solid rgba(255, 255, 255, 0.2)";
      });

      svgElements.forEach((svg) => {
        svg.setAttribute("stroke", "white");
      });

      barElements.forEach((bar) => {
        bar.style.background = "white";
      });

      modalElements.forEach((el) => {
        el.style.color = "white";
        el.style.background = "#474a47";
      });

      xSvg.style.fill = "white";
      svgWp.setAttribute("fill", "white");
    } else {
      body.style.background = "white";
      body.style.color = "black";
      navLinks.style.background = "white";
      nav.style.background = "white";
      html.style.background = "white";

      matches.forEach((a) => {
        a.style.color = "black";
      });

      cardElements.forEach((el) => {
        el.style.color = "black";
      });

      btnElements.forEach((btn) => {
        btn.style.color = "black";
        btn.style.border = "1px solid rgb(0 0 0 / 20%)";
      });

      svgElements.forEach((svg) => {
        svg.setAttribute("stroke", "black");
      });

      barElements.forEach((bar) => {
        bar.style.background = "#FD9346";
      });

      modalElements.forEach((el) => {
        el.style.color = "black";
        el.style.background = "white";
      });

      xSvg.style.fill = "black";
      svgWp.setAttribute("fill", "black");
    }
  };







  const [isNavVisible, setIsNavVisible] = useState(false);
  const toggleNav = () => {
    setIsNavVisible(!isNavVisible);
  };

  const [isNavbarScrolled, setIsNavbarScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.pageYOffset > 70) {
        setIsNavbarScrolled(true);
      } else {
        setIsNavbarScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const mode = () => {
    // Your mode function logic
  };

  return (
    <nav className={`nav ${isNavVisible ? 'show' : ''} ${isNavbarScrolled ? 'scrolled' : ''}`}>
      <div className="nav-content">
        <div className="logo-div">
          <a href="#" className="logo">
            <p style={{ fontWeight: 'bolder' }}>RY.</p>
          </a>
        </div>

        <div onClick={toggleNav} className="nav-icon">
          <div className="bar one"></div>
          <div className="bar two"></div>
          <div className="bar three"></div>
        </div>

        <div className="nav-links">
          <a href="#about">About Us</a>
          <a href="#skills">Why Billionaire Fund?</a>
          <a href="#works">Loan</a>
          <a href="#contact">Contact</a>
        </div>

        <button onClick={toggleMode} className="mode">
          <img
            style={{
              width: '18px',
              height: '18px',
            }}
            id="sun"
            src={isDarkMode ? require("../bgs/sun.png") : require("../bgs/moon.png")}
            alt={isDarkMode ? "sun" : "moon"}
          />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
