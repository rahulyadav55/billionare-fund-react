import React from 'react'

const skill = () => {
  return (
    <div>skill</div>
  )
}

export default skill