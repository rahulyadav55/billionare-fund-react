import React, { useState } from 'react';

const About = () => {
    const [showFullText, setShowFullText] = useState(false);

    const toggleText = () => {
        setShowFullText(!showFullText);
    };

    const [isParagraphVisible, setIsParagraphVisible] = useState(false);

    const toggleParagraph = () => {
        setIsParagraphVisible(!isParagraphVisible);
    };

    return (
        <div className="about" id="about">
            <div className="about-head">
                <h2 className="about-head-text">About Us</h2>
            </div>
            <div className="about-content">
                <p className="about-content-text">
                    Billionaire Fund is an Instant Personal Loan platform for self-employed and salaried professionals, where they can apply for a{' '}
                    <a style={{ color: '#FD9346' }} href="PersonalLoans.html">
                        Personal Loan
                    </a>{' '}
                    starting from ₹ 10000 up to ₹ 3 Lakhs as per their requirement......
                </p>

                {isParagraphVisible && (
                    <p id="para" className={`about-content-text ${showFullText ? '' : 'hidden'}`}>
                        We aim to become the first choice when it comes to quick and convenient Personal Loans. The documentation required is very minimal,
                        and the entire process - starting from registration on our website to loan disbursement does not take more than 15
                        minutes. The application process is completely online, and upon approval, the cash is immediately transferred
                        to the bank account of the user. We understand that when you’re in urgent need of funds, long waiting times
                        can be very frustrating, so we eliminated that completely.

                        Even if you haven’t taken a loan before, or don’t have a credit card, you can still avail loans with
                        Billionaire Fund. We offer loans in varying ticket sizes and repayment tenures, to suit all your unpredictable
                        financial needs. Most of the time, these come up without a warning and can be anything, like a sudden medical
                        emergency, festival shopping, paying your EMIs/bills, etc. Even if it’s something you want for yourself, like
                        a vacation, booking concert tickets or shopping online, we don’t believe that you must compromise on them just
                        because you have very little or no money. That’s where we come in!

                        We are here to solve the issue of easy credit among young professionals in India. The founding team feels that
                        the Indian demography has a large population of urban young adults that spends a lot online and offline. For such an
                        enormous ecosystem, the need for urgent personal finance for purchase requirements is highly under-served. An
                        appropriate focus towards tech-based credit evaluation can both help this demographic segment significantly
                        and also fuel the Indian economy by encouraging responsible spending behavior among individuals.
                    </p>
                )}

                <button onClick={toggleParagraph} className="btn card_btn" id="about-btn">
                    {isParagraphVisible ? 'Read less' : 'Read more'}
                </button>
            </div>
        </div>
    );
};

export default About;
